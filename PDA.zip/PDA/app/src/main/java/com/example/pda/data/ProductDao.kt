package com.example.pda.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface ProductDao {

    @Insert
    suspend fun insertProduct(product: ProductEntity): Long

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("DELETE FROM products WHERE tableId = :tableId")
    suspend fun deleteProductsForTable(tableId: Int): Int

    @Query("SELECT * FROM products WHERE tableId = :tableId")
    suspend fun getProductsForTable(tableId: Int): List<ProductEntity>

    @Query("UPDATE products SET comment = :comment WHERE id = :productId")
    suspend fun updateProductComment(productId: Int, comment: String)

    @Query("SELECT * FROM products ORDER BY timestamp ASC")
    fun getAllProductsOrderedByTimestamp(): List<ProductEntity>
}
