package com.example.pda

import android.os.Bundle
import android.util.Log
import android.widget.ListView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.example.pda.data.RestaurantDatabase
import kotlinx.coroutines.launch

class OrdersActivity : ComponentActivity() {

    private lateinit var db: RestaurantDatabase
    private lateinit var ordersList: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)

        // Initialize views
        ordersList = findViewById(R.id.orders_list)

        // Initialize database
        db = RestaurantDatabase.getDatabase(this)

        // Load and display all orders
        loadOrders()
    }

    private fun loadOrders() {
        lifecycleScope.launch {
            try {
                // Retrieve all products ordered by timestamp (FIFO)
                val products = db.productDao().getAllProductsOrderedByTimestamp()

                // Log the number of products
                Log.d("OrdersActivity", "Products: ${products.size}")

                // Create an adapter to display the products
                val adapter = OrdersAdapter(this@OrdersActivity, products)
                ordersList.adapter = adapter
            } catch (e: Exception) {
                // Log the error
                e.printStackTrace()
                Toast.makeText(this@OrdersActivity, "Failed to load orders: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}