package com.example.pda

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.pda.data.RestaurantDatabase
import android.os.Handler
import android.os.Looper

class MainActivity : ComponentActivity() {

    private var generalTotal: Double = 0.0
    private lateinit var generalTotalEditText: EditText
    private lateinit var clearGeneralTotalButton: Button
    private lateinit var sharedPreferences: SharedPreferences
    private val handler = Handler(Looper.getMainLooper()) // For auto-hiding the total

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        generalTotalEditText = findViewById(R.id.et_general_total)
        clearGeneralTotalButton = findViewById(R.id.btn_clear_general_total)

        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE)

        // Load saved general total
        generalTotal = sharedPreferences.getFloat("generalTotal", 0f).toDouble()
        hideGeneralTotal() // Hide it initially

        // 🔐 Require password to **view** general total
        generalTotalEditText.setOnClickListener {
            verifyPassword {
                showGeneralTotal()
                // Auto-hide after 5 seconds
                handler.postDelayed({ hideGeneralTotal() }, 5000)
            }
        }

        // 🔐 Require password to **edit** general total
        generalTotalEditText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                verifyPassword {
                    showGeneralTotal()
                }
            }
        }

        generalTotalEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                verifyPassword {
                    saveGeneralTotalFromEditText()
                    hideGeneralTotal()
                }
                true
            } else {
                false
            }
        }

        // 🔐 Require password to **clear** general total
        clearGeneralTotalButton.setOnClickListener {
            verifyPassword {
                confirmClearGeneralTotal()
            }
        }

        // Initialize database
        val db = RestaurantDatabase.getDatabase(applicationContext)

        val tableButtons = (1..24).map {
            findViewById<Button>(resources.getIdentifier("btn_table_$it", "id", packageName))
        }

        tableButtons.forEachIndexed { index, button ->
            val tableNumber = index + 1
            button.setOnClickListener {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("tableNumber", tableNumber)
                startActivityForResult(intent, tableNumber)
            }
        }
        // Set up Orders button listener
        findViewById<Button>(R.id.btn_manage_orders).setOnClickListener {
            val intent = Intent(this, OrdersActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            val addedAmount = data.getDoubleExtra("addedAmount", 0.0)
            generalTotal += addedAmount
            saveGeneralTotal()
            hideGeneralTotal()
            Toast.makeText(this, "General Total Updated!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showGeneralTotal() {
        generalTotalEditText.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        generalTotalEditText.setText("%.2f".format(generalTotal))
    }

    private fun hideGeneralTotal() {
        generalTotalEditText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        generalTotalEditText.setText("******")
    }

    private fun saveGeneralTotal() {
        val editor = sharedPreferences.edit()
        editor.putFloat("generalTotal", generalTotal.toFloat())
        editor.apply()
        Log.d("MainActivity", "Saved generalTotal: ${sharedPreferences.getFloat("generalTotal", 0f)}")
    }

    private fun saveGeneralTotalFromEditText() {
        try {
            val newTotal = generalTotalEditText.text.toString().toDouble()
            generalTotal = newTotal
            saveGeneralTotal()
            hideGeneralTotal()
            Toast.makeText(this, "General Total Updated!", Toast.LENGTH_SHORT).show()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Invalid input!", Toast.LENGTH_SHORT).show()
            hideGeneralTotal()
        }
    }

    private fun confirmClearGeneralTotal() {
        AlertDialog.Builder(this)
            .setTitle("Καθαρισμός")
            .setMessage("Είσαι σίγουρος πως θες να καθαρίσεις το γενικό σύνολο;")
            .setPositiveButton("Ναι") { _, _ ->
                generalTotal = 0.0
                saveGeneralTotal()
                hideGeneralTotal()
                Toast.makeText(this, "General Total Cleared!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Όχι", null)
            .show()
    }

    private fun verifyPassword(onSuccess: () -> Unit) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER

        AlertDialog.Builder(this)
            .setTitle("Εισαγωγή κωδικού")
            .setMessage("Εισήγαγε κωδικό για συνέχεια")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                if (input.text.toString() == "1821") {
                    onSuccess()
                } else {
                    Toast.makeText(this, "Incorrect password!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Ακύρωση", null)
            .show()
    }
}
