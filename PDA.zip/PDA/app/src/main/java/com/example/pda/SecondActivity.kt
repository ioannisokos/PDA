package com.example.pda

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color;
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.example.pda.data.RestaurantDatabase
import com.example.pda.data.ProductEntity
import kotlinx.coroutines.launch

class SecondActivity : ComponentActivity() {

    private lateinit var expandableListView: ExpandableListView
    private lateinit var selectedItemsList: ListView
    private lateinit var totalPriceTextView: TextView
    private lateinit var clearTableButton: Button
    private lateinit var stickyHeader: TextView

    private lateinit var db: RestaurantDatabase
    private var tableNumber: Int = 0
    private val selectedProducts = mutableListOf<ProductEntity>()
    private lateinit var selectedProductsAdapter: ArrayAdapter<String>

    private val categoryList = listOf("Καφέδες", "Σοκολάτες", "Κρύα τσαι","Ζεστό τσαι", "Αναψυκτικά", "Χυμοί", "Μπύρες", "Κρασιά", "Ποτά")
    private val productMap = mapOf(
        "Καφέδες" to listOf("Espresso μονό", "Espresso διπλό", "Freddo espresso", "Freddo cappuccino", "Cappuccino μονό", "Cappuccino διπλό", "Latte", "Macchiato μονό", "Macchiato διπλό", "Americano", "Ελληνικός μονός", "Ελληνικός διπλός", "Νες/φραπέ", "Γαλλικός"),
        "Σοκολάτες" to listOf("Σοκολάτα", "Σοκολάτα με σαντιγί", "Σοκολάτα λευκή", "Σοκολάτα καραμέλα", "Σοκολάτα φουντούκι", "Σοκολάτα φράουλα", "Σοκολάτα λευκή μαστίχα", "Σοκολάτα cranberry", "Σοκολάτα καυτερή"),
        "Κρύα τσαι" to listOf("Τσάι ροδάκινο", "Τσάι λεμόνι", "Τσάι χωρίς ζάχαρη"),
        "Ζεστό τσαι" to listOf("Caramel toffee","Jardin blue","Rooibos citrus","Carcadet fantasia"),
        "Αναψυκτικά" to listOf("Πορτοκαλάδα με ανθρακικό", "Πορτοκαλάδα χωρίς ανθρακικό", "Λεμονάδα", "Ροζ λεμονάδα", "Βυσσινάδα", "Coca-cola", "Coca-cola zero", "Ξινό νερό Φλώρινας"),
        "Χυμοί" to listOf("Φυσικός χυμός πορτοκάλι", "Χυμός πορτοκάλι", "Χυμός ροδάκινο", "Χυμός μπανάνα", "Χυμός βύσσινο", "Χυμός λεμόνι", "Χυμός ανάμεικτος", "Giagia mas λεμονάδα", "Giagia mas λεμόνι φράουλα", "Giagia mas πράσινο μήλο-ρόδι", "Giagia mas ροδακινάδα", "Giagia mas πανδαισία"),
        "Μπύρες" to listOf("Εζα lager", "Άλφα", "Κάιζερ", "Fisher", "Mythos ice", "Βαρέλι Άλφα"),
        "Κρασιά" to listOf("Λευκό ξηρό", "Λευκό ημίγλυκο", "Κόκκινο ξηρό", "Ροζέ ημίγλυκο", "Moschato dusty", "Sangria"),
        "Ποτά" to listOf("Τσίπουρο Τυρνάβου", "Τσίπουρο Ηδονικό", "Ούζο Τυρνάβου", "Ποτό απλό", "Ποτό special", "Ποτό premium", "Cocktail")
    )

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)

        // Initialize views
        expandableListView = findViewById(R.id.expandable_category_list)
        selectedItemsList = findViewById(R.id.selected_items_list)
        totalPriceTextView = findViewById(R.id.total_price)
        clearTableButton = findViewById(R.id.clear_table_button)
        stickyHeader = findViewById(R.id.sticky_header)

        // Get table number from intent
        tableNumber = intent.getIntExtra("tableNumber", 0)
        findViewById<TextView>(R.id.table_number).text = "Table $tableNumber"

        // Initialize database
        db = RestaurantDatabase.getDatabase(this)

        // Set up adapters
        selectedProductsAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        selectedItemsList.adapter = selectedProductsAdapter

        // Set up ExpandableListView
        setupExpandableListView()

        // Load table data
        loadTableData()

        // Set up button click listeners
        clearTableButton.setOnClickListener { clearTable() }

        // Set up item click listener for selected items list
        selectedItemsList.setOnItemClickListener { _, _, position, _ ->
            val selectedProduct = selectedProducts[position]
            showRemoveOrAddDialog(selectedProduct, position)
        }



        // Set up scroll listener for sticky header
        expandableListView.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {}

            override fun onScroll(
                view: AbsListView?,
                firstVisibleItem: Int,
                visibleItemCount: Int,
                totalItemCount: Int
            ) {
                updateStickyHeader(firstVisibleItem)
            }
        })
    }

    private fun showRemoveOrAddDialog(product: ProductEntity, position: Int) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Επιλογή")
            .setMessage("Τι θες να κανεις με ${product.name}?")
            .setPositiveButton("Πληρώθηκε") { _, _ ->
                addToGeneralTotal(product)
                removeProductFromTable(position)
            }
            .setNegativeButton("Αφαίρεση") { _, _ ->
                removeProductFromTable(position)
            }
            .setNeutralButton("Ακύρωση", null) // Do nothing on cancel
            .create()

        dialog.show()
    }

    private fun addToGeneralTotal(product: ProductEntity) {
        val resultIntent = Intent()
        resultIntent.putExtra("addedAmount", product.price) // Pass the amount
        setResult(RESULT_OK, resultIntent) // Set the result
        finish() // Finish the activity

        Toast.makeText(this, "Added ${product.price} to General Total", Toast.LENGTH_SHORT).show()
    }


    private fun setupExpandableListView() {
        val adapter = object : BaseExpandableListAdapter() {
            override fun getGroupCount() = categoryList.size
            override fun getChildrenCount(groupPosition: Int) = productMap[categoryList[groupPosition]]?.size ?: 0
            override fun getGroup(groupPosition: Int) = categoryList[groupPosition]
            override fun getChild(groupPosition: Int, childPosition: Int) = productMap[categoryList[groupPosition]]?.get(childPosition) ?: ""
            override fun getGroupId(groupPosition: Int) = groupPosition.toLong()
            override fun getChildId(groupPosition: Int, childPosition: Int) = childPosition.toLong()
            override fun hasStableIds() = false

            override fun getGroupView(
                groupPosition: Int,
                isExpanded: Boolean,
                convertView: View?,
                parent: ViewGroup?
            ): View {
                val groupName = getGroup(groupPosition) as String
                val textView = TextView(this@SecondActivity).apply {
                    text = groupName
                    textSize = 20f
                    setPadding(100, 30, 0, 30)
                }
                return textView
            }

            override fun getChildView(
                groupPosition: Int,
                childPosition: Int,
                isLastChild: Boolean,
                convertView: View?,
                parent: ViewGroup?
            ): View {
                val productName = getChild(groupPosition, childPosition)
                val category = getGroup(groupPosition) as String

                val layout = LinearLayout(this@SecondActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(50, 20, 20, 20)
                }

                var sugarOption: String? = null
                var temperatureOption: String? = null

                // Declare the commentInput before using it
                val commentInput = EditText(this@SecondActivity).apply {
                    hint = "Σχόλιο"
                }

                // Add the "Add Product" button first
                val addButton = Button(this@SecondActivity).apply {
                    text = "$productName"
                    setBackgroundColor(Color.parseColor("#008080")) // Set button color
                    setTextColor(Color.WHITE) // Set text color
                    setOnClickListener {
                        val comment = commentInput.text.toString()
                        // Include sugarOption for "Καφέδες" and temperatureOption for "Σοκολάτες"
                        val finalProductName = when {
                            category == "Καφέδες" && sugarOption != null -> "$productName - $sugarOption"
                            category == "Σοκολάτες" && temperatureOption != null -> "$productName - $temperatureOption"
                            else -> productName
                        }
                        addProductToTable(finalProductName, sugarOption ?: "Μέτριος", comment)
                    }
                }
                layout.addView(addButton)

                // Declare CheckBox variables outside the listener
                lateinit var checkBoxSugar: CheckBox
                lateinit var checkBoxNoSugar: CheckBox
                lateinit var checkBoxSugarSugar: CheckBox
                lateinit var checkBoxHot: CheckBox
                lateinit var checkBoxCold: CheckBox

                // Add the CheckBoxes for the "Καφέδες" category
                if (category == "Καφέδες") {
                    checkBoxSugar = CheckBox(this@SecondActivity).apply {
                        text = "Σκέτος"
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                sugarOption = "Σκέτος"
                                // Uncheck other sugar options
                                checkBoxNoSugar.isChecked = false
                                checkBoxSugarSugar.isChecked = false
                            }
                        }
                    }

                    checkBoxNoSugar = CheckBox(this@SecondActivity).apply {
                        text = "Μέτριος"
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                sugarOption = "Μέτριος"
                                // Uncheck other sugar options
                                checkBoxSugar.isChecked = false
                                checkBoxSugarSugar.isChecked = false
                            }
                        }
                    }

                    checkBoxSugarSugar = CheckBox(this@SecondActivity).apply {
                        text = "Γλυκός"
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                sugarOption = "Γλυκός"
                                // Uncheck other sugar options
                                checkBoxSugar.isChecked = false
                                checkBoxNoSugar.isChecked = false
                            }
                        }
                    }

                    layout.addView(checkBoxSugar)
                    layout.addView(checkBoxNoSugar)
                    layout.addView(checkBoxSugarSugar)
                }

                // Add the CheckBoxes for the "Σοκολάτες" category
                if (category == "Σοκολάτες") {
                    checkBoxHot = CheckBox(this@SecondActivity).apply {
                        text = "Ζεστή"
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                temperatureOption = "Ζεστή"
                                // Uncheck the other temperature option
                                checkBoxCold.isChecked = false
                            }
                        }
                    }

                    checkBoxCold = CheckBox(this@SecondActivity).apply {
                        text = "Κρύα"
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) {
                                temperatureOption = "Κρύα"
                                // Uncheck the other temperature option
                                checkBoxHot.isChecked = false
                            }
                        }
                    }

                    layout.addView(checkBoxHot)
                    layout.addView(checkBoxCold)
                }

                // Add the comment input last
                layout.addView(commentInput)

                return layout
            }

            override fun isChildSelectable(groupPosition: Int, childPosition: Int) = true
        }

        expandableListView.setAdapter(adapter)
    }

    private fun updateStickyHeader(firstVisibleItem: Int) {
        // Get the position of the first visible item
        val packedPosition = expandableListView.getExpandableListPosition(firstVisibleItem)
        val groupPosition = ExpandableListView.getPackedPositionGroup(packedPosition)

        if (groupPosition >= 0) {
            // Get the category name for the current group
            val category = categoryList[groupPosition]
            stickyHeader.text = category
            stickyHeader.visibility = View.VISIBLE
        } else {
            // Hide the sticky header if no group is visible
            stickyHeader.visibility = View.GONE
        }
        stickyHeader.setOnClickListener {
            val packedPosition = expandableListView.getExpandableListPosition(firstVisibleItem)
            val groupPosition = ExpandableListView.getPackedPositionGroup(packedPosition)

            if (expandableListView.isGroupExpanded(groupPosition)) {
                expandableListView.collapseGroup(groupPosition)
            } else {
                expandableListView.expandGroup(groupPosition)
            }
        }
    }

    private fun addProductToTable(productName: String, sugarOption: String, comment: String) {
        // Remove any additional options (e.g., " - Hot" or " - Cold") before calculating the price
        val baseProductName = productName.split(" - ")[0]
        val price = getProductPrice(baseProductName)

        val product = ProductEntity(
            name = productName, // Includes temperature option if applicable
            price = price,
            tableId = tableNumber,
            comment = comment,
            timestamp = System.currentTimeMillis() // Add the current timestamp
        )

        lifecycleScope.launch {
            db.productDao().insertProduct(product)
            loadTableData()
        }

        Toast.makeText(this, "$productName added!", Toast.LENGTH_SHORT).show()
    }

    private fun getProductPrice(productName: String): Double {
        return when (productName) {
            "Espresso μονό" -> 2.5
            "Espresso διπλό" -> 3.5
            "Freddo espresso" -> 3.5
            "Freddo cappuccino" -> 3.5
            "Cappuccino μονό" -> 3.5
            "Cappuccino διπλό" -> 4.0
            "Latte ζεστό/κρύο" -> 4.0
            "Macchiato μονό" -> 3.0
            "Macchiato διπλό" -> 3.50
            "Americano" -> 3.0
            "Ελληνικός μονός" -> 3.0
            "Ελληνικός διπλός" -> 3.5
            "Νες /φραπέ" -> 3.0
            "Γαλλικός" -> 3.0
            "Σοκολάτα" -> 4.0
            "Σοκολάτα με σαντιγί" -> 4.0
            "Σοκολάτα λευκή" -> 4.0
            "Σοκολάτα καραμέλα" -> 4.0
            "Σοκολάτα φουντούκι" -> 4.0
            "Σοκολάτα φράουλα" -> 4.0
            "Σοκολάτα λευκή μαστίχα" -> 4.0
            "Σοκολάτα cranberry" -> 4.0
            "Σοκολάτα καυτερή" -> 4.0
            "Πορτοκαλάδα με ανθρακικό" -> 3.0
            "Πορτοκαλάδα χωρίς ανθρακικό" -> 3.0
            "Λεμονάδα" -> 3.0
            "Ροζ λεμονάδα" -> 3.0
            "Βυσσινάδα" -> 3.0
            "Coca-cola" -> 3.0
            "Coca-cola zero" -> 3.0
            "Ξινό νερό Φλώρινας" -> 3.0
            "Τσάι ροδάκινο" -> 3.0
            "Τσάι λεμόνι" -> 3.0
            "Τσάι χωρίς ζάχαρη" -> 3.0
            "Caramel toffee" -> 3.5
            "Jardin blue" -> 3.5
            "Rooibos citrus" -> 3.5
            "Carcadet fantasia" -> 3.5
            "Φυσικός χυμός πορτοκάλι" -> 4.0
            "Χυμός πορτοκάλι" -> 3.0
            "Χυμός ροδάκινο" -> 3.0
            "Χυμός μπανάνα" -> 3.0
            "Χυμός βύσσινο" -> 3.0
            "Χυμός λεμόνι" -> 3.0
            "Χυμός ανάμεικτος" -> 3.0
            "Giagia mas λεμονάδα" -> 3.5
            "Giagia mas λεμόνι φράουλα" -> 3.5
            "Giagia mas πράσινο μήλο-ρόδι" -> 3.5
            "Giagia mas ροδακινάδα" -> 3.5
            "Giagia mas πανδαισία" -> 3.5
            "Εζα lager" -> 3.5
            "Άλφα" -> 3.5
            "Κάιζερ" -> 3.5
            "Fisher" -> 3.5
            "Mythos ice" -> 3.5
            "Βαρέλι Άλφα" -> 3.5
            "Λευκό ξηρό" -> 4.0
            "Λευκό ημίγλυκο" -> 4.0
            "Κόκκινο ξηρό" -> 4.0
            "Ροζέ ημίγλυκο" -> 4.0
            "Moschato dusty" -> 5.0
            "Sangria" -> 4.0
            "Τσίπουρο Τυρνάβου" -> 3.5
            "Τσίπουρο Ηδονικό" -> 3.5
            "Ούζο Τυρνάβου" -> 3.5
            "Ποτό απλό" -> 6.0
            "Ποτό special" -> 7.0
            "Ποτό premium" -> 10.0
            "Cocktail" -> 6.0
            else -> 0.0
        }
    }

    private fun loadTableData() {
        lifecycleScope.launch {
            val products = db.productDao().getProductsForTable(tableNumber)
            selectedProducts.clear()
            selectedProducts.addAll(products)
            updateSelectedProductsUI()
            updateTotalPrice()
        }
    }

    private fun updateSelectedProductsUI() {
        val productNames = selectedProducts.map {
            if (it.comment.isNullOrBlank()) "${it.name} - $${"%.2f".format(it.price)}"
            else "${it.name} - $${"%.2f".format(it.price)}\nComment: ${it.comment}"
        }

        selectedProductsAdapter.clear()
        selectedProductsAdapter.addAll(productNames)
        selectedProductsAdapter.notifyDataSetChanged()
    }

    private fun updateTotalPrice() {
        val totalPrice = selectedProducts.sumOf { it.price }
        totalPriceTextView.text = "Σύνολο: $${"%.2f".format(totalPrice)}"
    }

    private fun removeProductFromTable(position: Int) {
        val productToRemove = selectedProducts[position]

        lifecycleScope.launch {
            db.productDao().deleteProduct(productToRemove)
            loadTableData()
        }
    }

    private fun clearTable() {
        lifecycleScope.launch {
            // Calculate the total price of the table
            val totalPrice = selectedProducts.sumOf { it.price }

            // Add the total price to the general total
            val resultIntent = Intent()
            resultIntent.putExtra("addedAmount", totalPrice)
            setResult(RESULT_OK, resultIntent)

            // Delete the products from the table
            db.productDao().deleteProductsForTable(tableNumber)
            selectedProducts.clear()
            updateSelectedProductsUI()
            updateTotalPrice()

            // Show a confirmation message
            Toast.makeText(this@SecondActivity, "Table cleared and $totalPrice added to General Total!", Toast.LENGTH_SHORT).show()
        }
        clearTableButton.setOnClickListener {
            clearTable()
            finish() // Finish the activity after clearing the table
        }
    }


}
