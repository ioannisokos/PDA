package com.example.pda.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TableDao {
    @Insert
    fun insert(table: TableEntity)

    @Query("SELECT * FROM TableEntity WHERE id = :tableId")
    fun getTableById(tableId: Int): TableEntity?

}
