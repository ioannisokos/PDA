package com.example.pda.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val price: Double,
    val tableId: Int,
    val comment: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
