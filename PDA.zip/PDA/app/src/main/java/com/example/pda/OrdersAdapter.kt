package com.example.pda

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.pda.data.ProductEntity

class OrdersAdapter(context: Context, private val products: List<ProductEntity>) :
    ArrayAdapter<ProductEntity>(context, 0, products) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val product = products[position]

        val view = convertView ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)

        // Display the product name and table number
        view.findViewById<TextView>(android.R.id.text1).text = product.name
        view.findViewById<TextView>(android.R.id.text2).text = "Table ${product.tableId} - $${"%.2f".format(product.price)}"

        return view
    }
}